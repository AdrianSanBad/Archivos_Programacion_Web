<?php
require('fpdf/fpdf.php'); // Asegúrate de tener la librería FPDF en esta ruta

// Conexión a la base de datos
include 'conexion.php';

// Obtener parámetro de búsqueda
$busqueda = isset($_POST['query']) ? $_POST['query'] : '';

// Consulta a la base de datos
$sql = "SELECT * FROM personal 
        WHERE curp LIKE '%$busqueda%' 
        OR nombre LIKE '%$busqueda%' 
        OR apellidos LIKE '%$busqueda%'
        OR email LIKE '%$busqueda%'
        ORDER BY id DESC";
$result = $conn->query($sql);

// Crear PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Título
$pdf->Cell(0, 10, 'Resultados de Busqueda', 0, 1, 'C');
$pdf->Ln(10);

// Información de la búsqueda
if (!empty($busqueda)) {
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, "Termino buscado: " . utf8_decode($busqueda), 0, 1);
    $pdf->Ln(5);
}

// Cabecera de la tabla
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 7, 'ID', 1);
$pdf->Cell(30, 7, 'CURP', 1);
$pdf->Cell(30, 7, 'Nombre', 1);
$pdf->Cell(30, 7, 'Apellidos', 1);
$pdf->Cell(40, 7, 'Email', 1);
$pdf->Cell(25, 7, 'Teléfono', 1);
$pdf->Ln();

// Contenido de la tabla
$pdf->SetFont('Arial', '', 8);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(10, 6, $row['id'], 1);
        $pdf->Cell(30, 6, utf8_decode($row['curp']), 1);
        $pdf->Cell(30, 6, utf8_decode($row['nombre']), 1);
        $pdf->Cell(30, 6, utf8_decode($row['apellidos']), 1);
        $pdf->Cell(40, 6, utf8_decode($row['email']), 1);
        $pdf->Cell(25, 6, utf8_decode($row['telefono']), 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0, 6, 'No se encontraron resultados', 1, 1, 'C');
}

// Pie de página
$pdf->SetY(-15);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(0, 10, 'Generado el ' . date('d/m/Y H:i:s'), 0, 0, 'C');

// Salida del PDF
$pdf->Output('D', 'resultados_busqueda.pdf'); // 'D' fuerza la descarga
$conn->close();
?>