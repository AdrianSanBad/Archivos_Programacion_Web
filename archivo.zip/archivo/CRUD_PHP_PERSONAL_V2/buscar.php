<?php
// Conexión a la base de datos
include 'conexion.php';

// Procesar búsqueda si se envió el formulario
$resultados = [];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['query'])) {
    $busqueda = $_GET['query'];
    $sql = "SELECT * FROM personal 
            WHERE curp LIKE '%$busqueda%' 
            OR nombre LIKE '%$busqueda%' 
            OR apellidos LIKE '%$busqueda%'
            OR email LIKE '%$busqueda%'
            ORDER BY id DESC";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $resultados[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda de Personal</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/stylesalta.css">
</head>
<body>
    <header class="encabezado">
        <h1>Búsqueda de Personal</h1>
        <a href="index.php">Regresar a inicio</a>
    </header>
    
    <section class="contenido">
        <!-- Formulario de búsqueda -->
        <div class="search-form mb-4">
            <form action="buscar.php" method="GET" class="d-flex">
                <input type="text" name="query" class="form-control me-2" 
                       placeholder="Buscar por CURP, nombre, apellidos o email..." 
                       value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </form>
        </div>

        <!-- Resultados de la búsqueda -->
        <?php if (!empty($resultados)): ?>
            <div class="table-container">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>CURP</th>
                            <th>Nombre</th>
                            <th>Apellidos</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resultados as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['curp']); ?></td>
                                <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($row['apellidos']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <!-- Botón para generar PDF -->
                <div class="text-center mt-4">
                    <form action="generar_pdf.php" method="POST" target="_blank">
                        <input type="hidden" name="query" value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>">
                        <button type="submit" class="btn btn-success">Generar PDF</button>
                    </form>
                </div>
            </div>
        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['query'])): ?>
            <div class="alert alert-warning">No se encontraron resultados para "<?php echo htmlspecialchars($_GET['query']); ?>"</div>
        <?php endif; ?>
    </section>
    
    <footer class="pie">
        <p>Derechos Reservados © 2025</p>
    </footer>
</body>
</html>