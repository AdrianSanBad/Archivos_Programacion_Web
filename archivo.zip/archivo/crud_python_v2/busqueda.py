from flask import Blueprint, render_template, request, redirect, url_for, make_response, flash
from conexion import obtener_conexion
from fpdf import FPDF

busqueda_bp = Blueprint('busqueda_bp', __name__)

@busqueda_bp.route('/busqueda', methods=['GET', 'POST'])
def busqueda():
    datos = None
    mensaje = None
    if request.method == 'POST':
        curp = request.form['curp']
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        cursor.execute("SELECT * FROM personal WHERE curp = %s", (curp,))
        datos = cursor.fetchone()
        cursor.close()
        conexion.close()
        if not datos:
            mensaje = "CURP no encontrado"
    return render_template('busqueda.html', datos=datos, mensaje=mensaje)


@busqueda_bp.route('/generar_pdf', methods=['POST'])
def generar_pdf():
    curp = request.form['curp']
    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM personal WHERE curp = %s", (curp,))
    datos = cursor.fetchone()
    cursor.close()
    conexion.close()

    if not datos:
        flash("CURP no encontrado para generar PDF")
        return redirect(url_for('busqueda_bp.busqueda'))

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Datos del Registro", ln=True, align='C')
    pdf.ln(10)

    for clave, valor in datos.items():
        pdf.cell(200, 10, txt=f"{clave}: {valor}", ln=True)

    response = make_response(pdf.output(dest='S').encode('latin-1'))
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=registro_{curp}.pdf'
    return response
